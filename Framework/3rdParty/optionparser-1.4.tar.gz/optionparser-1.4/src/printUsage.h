/**
 * @file
 * @brief Dummy file for documentation purposes.
 */

/**
 * @brief @ref option::printUsage() formats the usage message with column alignment and line wrapping.
 */
class UsageMsg{
  // Dummy file to get an entry for printUsage() in Classes.
};
